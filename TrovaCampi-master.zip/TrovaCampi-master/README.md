# TrovaCampi

Nome gruppo: Brianzoli

Membri:

Davide Zangari 844760

Matteo Chiappelloni 852058

Luca Galliani 851634

Samuele Ghezzi 856631

Francesco Giannone 851582
